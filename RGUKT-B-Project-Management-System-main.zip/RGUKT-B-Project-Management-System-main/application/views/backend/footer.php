<!-- Footer -->
<footer class="main hidden-print">
	<strong> <?php echo get_settings('website_title'); ?> </strong> | &copy; 2021,
	<a href="<?php echo get_settings('footer_link'); ?>"
    	target="_blank"><?php echo get_settings('footer_text'); ?></a>
</footer>
