<div class="container margin_60">
  <div class="row justify-content-center">
    <div class="col-xl-6 col-lg-6 col-md-8">
      <div class="box_account">
        <h3 class="new_client"><?php echo get_phrase('new_user'); ?></h3>
        <p><span style="color: red;">You do not have the permission to crete an account</span>, only group leaders from each group can join and add their project.</p>
        <p>Group leader send a mail to rguktbprojects@gmail.com with your projct details and get the credentials.</p>
        
      </div>
    </div>
  </div>
</div>
