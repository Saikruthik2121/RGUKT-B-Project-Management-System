This project is my Engineering 3rd year mini project. We have built a project management system application where we can maintain a catalog of all the projects done by the students of RGUKT Basar. 
Here is the project link: https://rguktb.42web.io/
